
#[allow(unused_imports)]
#[allow(unused_variables)]
#[allow(dead_code)]
#[allow(non_snake_case)]

use std::collections::{HashMap, HashSet};
use num_bigint::BigInt;
use std::any::Any;
use std::rc::Rc;
use std::sync::Arc;
use std::fmt::Debug;
use std::fmt::Display;

use lz_builtins::*;

const __name__: &str = "main";

const __file__: &str = "bigint_min.lz";

const __package__: &str = "probe";

const __path__: &str = "E:/IDEProjects/AI/lang-zone/.fist-hunt-20260926/probe";

const __doc__: &str = "";

const __is_macro__: bool = false;

const x: num_bigint::BigInt = 12345678901234567890i128;

const y: num_bigint::BigInt = x * 100i64;

pub fn main() {
    // STMT:Expr
    return println!("{:?}", y);
}
