
#[allow(unused_imports)]
#[allow(unused_variables)]
#[allow(dead_code)]
#[allow(non_snake_case)]

use std::collections::{HashMap, HashSet};
use std::any::Any;
use std::rc::Rc;
use std::sync::Arc;
use std::fmt::Debug;
use std::fmt::Display;

use lz_builtins::*;

const __name__: &str = "main";

const __file__: &str = "rv_list3.lz";

const __package__: &str = "probe";

const __path__: &str = "E:/IDEProjects/AI/lang-zone/.fist-hunt-20260926/probe";

const __doc__: &str = "";

const __is_macro__: bool = false;

static a: std::sync::LazyLock<Vec<Vec<Vec<i64>>>> = std::sync::LazyLock::new(|| vec![Vec::<i64>::new(), vec![Vec::<i64>::new()]]);

pub fn main() {
    // STMT:Expr
    return println!("{:?}", vec![(), vec![()]]);
}
