
#[allow(unused_imports)]
#[allow(unused_variables)]
#[allow(dead_code)]
#[allow(non_snake_case)]

use std::collections::{HashMap, HashSet};
use std::any::Any;
use std::rc::Rc;
use std::sync::Arc;
use std::fmt::Debug;
use std::fmt::Display;

use lz_builtins::*;

#[allow(non_snake_case)] #[allow(dead_code)]
fn println(__a0: i64) -> i64 { i64::MAX }

pub fn main() {
    // STMT:Let
    let x = 12345678901234567890i128;
    // STMT:Let
    let y = x * 100i64;
    // STMT:Expr
    println!("{:?}", y);
}

const __name__: &str = "main";

const __file__: &str = "bigint_fnbody.lz";

const __package__: &str = "probe";

const __path__: &str = "E:/IDEProjects/AI/lang-zone/.fist-hunt-20260926/probe";

const __doc__: &str = "";

const __is_macro__: bool = false;

