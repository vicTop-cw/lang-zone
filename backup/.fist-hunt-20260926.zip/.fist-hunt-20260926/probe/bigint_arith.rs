
#[allow(unused_imports)]
#[allow(unused_variables)]
#[allow(dead_code)]
#[allow(non_snake_case)]

use std::collections::{HashMap, HashSet};
use num_bigint::BigInt;
use std::any::Any;
use std::rc::Rc;
use std::sync::Arc;
use std::fmt::Debug;
use std::fmt::Display;

use lz_builtins::*;

const __name__: &str = "main";

const __file__: &str = "bigint_arith.lz";

const __package__: &str = "probe";

const __path__: &str = "E:/IDEProjects/AI/lang-zone/.fist-hunt-20260926/probe";

const __doc__: &str = "";

const __is_macro__: bool = false;

const a: num_bigint::BigInt = 99999999999999999999999999999i128;

const b: i64 = 42i64;

const c: num_bigint::BigInt = a + 42i64;

pub fn main() {
    // STMT:Expr
    return println!("{:?}", c);
}
