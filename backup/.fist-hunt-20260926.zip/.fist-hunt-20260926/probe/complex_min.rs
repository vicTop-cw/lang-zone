
#[allow(unused_imports)]
#[allow(unused_variables)]
#[allow(dead_code)]
#[allow(non_snake_case)]

use std::collections::{HashMap, HashSet};
use num_complex::Complex64;
use std::any::Any;
use std::rc::Rc;
use std::sync::Arc;
use std::fmt::Debug;
use std::fmt::Display;

use lz_builtins::*;

const __name__: &str = "main";

const __file__: &str = "complex_min.lz";

const __package__: &str = "probe";

const __path__: &str = "E:/IDEProjects/AI/lang-zone/.fist-hunt-20260926/probe";

const __doc__: &str = "";

const __is_macro__: bool = false;

const z: num_complex::Complex64 = num_complex::Complex64::new(1.0f64, 0.0) + num_complex::Complex64::new(0.0, 2.0);

pub fn main() {
    // STMT:Expr
    return println!("{:?}", z);
}
