use std::rc::Rc;

fn hof(g: impl Fn(i64) -> i64) -> i64 {
    g(1)
}

fn hof_impl_fn_static(g: impl Fn(i64) -> i64 + 'static) -> Box<dyn Fn(i64) -> i64> {
    Box::new(move |x| g(x))
}

fn main() {
    let f: Rc<dyn Fn(i64) -> i64> = Rc::new(|x| x + 1);
    // 1) Rc<dyn Fn> 能否直接调用？
    let a = f(2);
    // 2) clone 是否可用？
    let g = f.clone();
    // 3) 能否传给 impl Fn 形参？
    let b = hof(f.clone());
    // 4) 能否传给 impl Fn + 'static 形参并装箱返回？
    let h = hof_impl_fn_static(f.clone());
    let c = h(5);
    // 5) 以 &Rc<dyn Fn> 传递
    let d = hof(&*f);
    println!("{} {} {} {} {}", a, g(1), b, c, d);
}
