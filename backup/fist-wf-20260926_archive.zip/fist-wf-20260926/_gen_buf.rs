
#[allow(unused_imports)]
#[allow(unused_variables)]
#[allow(dead_code)]
#[allow(non_snake_case)]

use std::collections::{HashMap, HashSet};
use std::any::Any;
use std::rc::Rc;
use std::sync::Arc;
use std::fmt::Debug;
use std::fmt::Display;

use lz_builtins::*;

pub fn test_params_mixed() {
    // STMT:Let
    let mut p = __Params::PATHnew();
    // STMT:Expr
    p.set(0i64, 42i64);
    // STMT:Expr
    p.set(1i64, "hello".to_string());
    // STMT:Let
    let mut val0 = p.get((0i64 as usize));
    // STMT:Expr
    return println!("{:?} {:?}", "param[0]:".to_string(), val0);
}

pub fn main() {
    // STMT:Expr
    test_params_mixed();
    // STMT:Expr
    println!("{:?}", "params-type-erase.lz done".to_string());
}

const __name__: &str = "main";

const __file__: &str = "bug-params-type-erase.lz";

const __package__: &str = "typer";

const __path__: &str = "FIND_BUG\\typer";

const __doc__: &str = "";

const __is_macro__: bool = false;

