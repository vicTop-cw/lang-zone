use std::rc::Rc;

// 目标形态：值位置 / HOF 形参 / 返回位置统一 Rc<dyn Fn>
fn apply_twice(f: Rc<dyn Fn(i64) -> i64>, x: i64) -> i64 {
    f(f(x))
}

fn compose(f: Rc<dyn Fn(i64) -> i64>, g: Rc<dyn Fn(i64) -> i64>) -> Rc<dyn Fn(i64) -> i64> {
    Rc::new(move |x| f(g(x)))
}

fn curried_add(a: i64) -> Rc<dyn Fn(i64) -> i64> {
    Rc::new(move |b: i64| a + b)
}

fn double(x: i64) -> i64 {
    x * 2
}

fn main() {
    let dbl: Rc<dyn Fn(i64) -> i64> = Rc::new(move |x: i64| x * 2);
    let r1 = apply_twice(dbl.clone(), 5); // 克隆 + 传参
    let dbl2: Rc<dyn Fn(i64) -> i64> = Rc::new(double); // fn item 作值
    let inc: Rc<dyn Fn(i64) -> i64> = Rc::new(move |x: i64| x + 1);
    let square: Rc<dyn Fn(i64) -> i64> = Rc::new(move |x: i64| x * x);
    let c1 = compose(square.clone(), inc.clone());
    let c2 = compose(inc.clone(), square.clone());
    let ops: Vec<Rc<dyn Fn(i64) -> i64>> = vec![Rc::new(move |x: i64| x + 1), Rc::new(double)];
    let a5 = curried_add(5);
    // 直接调用 Rc<dyn Fn>
    let r2 = dbl(3);
    let r3 = a5(3);
    let r4 = ops[0](3);
    let r5 = ops[1](3);
    println!("{} {} {} {} {} {} {} {}", r1, c1(3), c2(3), r2, r3, r4, r5, dbl2(9));
}
