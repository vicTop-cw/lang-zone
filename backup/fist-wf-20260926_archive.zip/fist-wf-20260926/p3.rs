
#[allow(unused_imports)]
#[allow(unused_variables)]
#[allow(dead_code)]
#[allow(non_snake_case)]

use std::collections::{HashMap, HashSet};
use std::any::Any;
use std::rc::Rc;
use std::sync::Arc;
use std::fmt::Debug;
use std::fmt::Display;

use lz_builtins::*;

#[allow(non_snake_case)] #[allow(dead_code)]
fn println(__a0: i64) -> i64 { i64::MAX }

#[derive(Debug, Clone, PartialEq)]
pub struct Big {
    pub val: lz_builtins::BigInt,
}

pub fn main() {
    // STMT:Let
    let b = Big { val: 42i64 };
    // STMT:Expr
    println!("{:?}", b.val);
}

const __name__: &str = "main";

const __file__: &str = "p3.lz";

const __package__: &str = ".fist-wf-20260926";

const __path__: &str = ".fist-wf-20260926";

const __doc__: &str = "";

const __is_macro__: bool = false;

