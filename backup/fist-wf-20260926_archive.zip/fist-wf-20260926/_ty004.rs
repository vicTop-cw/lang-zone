Generated FIND_BUG\typer\bug-params-type-erase.lz -> FIND_BUG\typer/bug-params-type-erase.rs (IR codegen)
