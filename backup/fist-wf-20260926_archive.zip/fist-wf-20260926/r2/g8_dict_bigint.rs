
#[allow(unused_imports)]
#[allow(unused_variables)]
#[allow(dead_code)]
#[allow(non_snake_case)]

use std::collections::{HashMap, HashSet};
use std::collections::BTreeMap;
use std::any::Any;
use std::rc::Rc;
use std::sync::Arc;
use std::fmt::Debug;
use std::fmt::Display;

use lz_builtins::*;

#[allow(non_snake_case)] #[allow(dead_code)]
fn println(__a0: i64) -> i64 { i64::MAX }

pub fn main() {
    // STMT:Let
    let m = std::collections::BTreeMap::from([(BigInt::from(1i64), 10i64), (BigInt::from(2i64), 20i64)]);
    // STMT:Expr
    println!("{:?}", m);
}

const __name__: &str = "main";

const __file__: &str = "g8_dict_bigint.lz";

const __package__: &str = "r2";

const __path__: &str = ".fist-wf-20260926\\r2";

const __doc__: &str = "";

const __is_macro__: bool = false;

