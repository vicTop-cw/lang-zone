
#[allow(unused_imports)]
#[allow(unused_variables)]
#[allow(dead_code)]
#[allow(non_snake_case)]

use std::collections::{HashMap, HashSet};
use std::any::Any;
use std::rc::Rc;
use std::sync::Arc;
use std::fmt::Debug;
use std::fmt::Display;

use lz_builtins::*;

#[allow(non_snake_case)] #[allow(dead_code)]
fn println(__a0: i64) -> i64 { i64::MAX }

pub fn main() {
    // STMT:Let
    let x: lz_builtins::BigInt = BigInt::from(100i64);
    // STMT:Let
    let y: lz_builtins::BigInt = (x).clone() / (BigInt::from(7i64)).clone();
    // STMT:Let
    let z: lz_builtins::BigInt = (x).clone() % (BigInt::from(7i64)).clone();
    // STMT:Expr
    println!("{:?}", y);
    // STMT:Expr
    println!("{:?}", z);
}

const __name__: &str = "main";

const __file__: &str = "g6_bigint_div.lz";

const __package__: &str = "r2";

const __path__: &str = ".fist-wf-20260926\\r2";

const __doc__: &str = "";

const __is_macro__: bool = false;

