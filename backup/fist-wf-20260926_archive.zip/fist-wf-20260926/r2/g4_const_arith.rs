
#[allow(unused_imports)]
#[allow(unused_variables)]
#[allow(dead_code)]
#[allow(non_snake_case)]

use std::collections::{HashMap, HashSet};
use std::any::Any;
use std::rc::Rc;
use std::sync::Arc;
use std::fmt::Debug;
use std::fmt::Display;

use lz_builtins::*;

#[allow(non_snake_case)] #[allow(dead_code)]
fn println(__a0: i64) -> i64 { i64::MAX }

pub fn main() {
    // STMT:Expr
    println!("{:?}", (*K).clone());
}

const __name__: &str = "main";

const __file__: &str = "g4_const_arith.lz";

const __package__: &str = "r2";

const __path__: &str = ".fist-wf-20260926\\r2";

const __doc__: &str = "";

const __is_macro__: bool = false;

static K: std::sync::LazyLock<lz_builtins::BigInt> = std::sync::LazyLock::new(|| LzAdd::__add__((BigInt::from(10i64)).clone() * (BigInt::from(20i64)).clone(), BigInt::from(5i64)));

