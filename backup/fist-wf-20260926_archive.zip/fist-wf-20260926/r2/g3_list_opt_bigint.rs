
#[allow(unused_imports)]
#[allow(unused_variables)]
#[allow(dead_code)]
#[allow(non_snake_case)]

use std::collections::{HashMap, HashSet};
use std::any::Any;
use std::rc::Rc;
use std::sync::Arc;
use std::fmt::Debug;
use std::fmt::Display;

use lz_builtins::*;

#[allow(non_snake_case)] #[allow(dead_code)]
fn println(__a0: i64) -> i64 { i64::MAX }

pub fn main() {
    // STMT:Let
    let xs: Vec<lz_builtins::BigInt> = vec![BigInt::from(1i64), BigInt::from(2i64), BigInt::from(3i64)];
    // STMT:Let
    let o: Option<lz_builtins::BigInt> = Some(BigInt::from(42i64));
    // STMT:Expr
    println!("{:?}", xs);
    // STMT:Expr
    println!("{:?}", o);
}

const __name__: &str = "main";

const __file__: &str = "g3_list_opt_bigint.lz";

const __package__: &str = "r2";

const __path__: &str = ".fist-wf-20260926\\r2";

const __doc__: &str = "";

const __is_macro__: bool = false;

