
#[allow(unused_imports)]
#[allow(unused_variables)]
#[allow(dead_code)]
#[allow(non_snake_case)]

use std::collections::{HashMap, HashSet};
use std::any::Any;
use std::rc::Rc;
use std::sync::Arc;
use std::fmt::Debug;
use std::fmt::Display;

use lz_builtins::*;

#[allow(non_snake_case)] #[allow(dead_code)]
fn println(__a0: i64) -> i64 { i64::MAX }

pub fn main() {
    // STMT:Let
    let a: lz_builtins::Complex64 = Complex64::new(1.0f64, 2.0f64);
    // STMT:Let
    let b: lz_builtins::Complex64 = Complex64::new(3.0f64, 4.0f64);
    // STMT:Let
    let c: lz_builtins::Complex64 = (a).clone() * (b).clone();
    // STMT:Let
    let d: lz_builtins::Complex64 = (a).clone() + (b).clone();
    // STMT:Expr
    println!("{:?}", c);
    // STMT:Expr
    println!("{:?}", d);
}

const __name__: &str = "main";

const __file__: &str = "g2_complex_arith.lz";

const __package__: &str = "r2";

const __path__: &str = ".fist-wf-20260926\\r2";

const __doc__: &str = "";

const __is_macro__: bool = false;

