
#[allow(unused_imports)]
#[allow(unused_variables)]
#[allow(dead_code)]
#[allow(non_snake_case)]

use std::collections::{HashMap, HashSet};
use std::any::Any;
use std::rc::Rc;
use std::sync::Arc;
use std::fmt::Debug;
use std::fmt::Display;

use lz_builtins::*;

#[allow(non_snake_case)] #[allow(dead_code)]
fn println(__a0: i64) -> i64 { i64::MAX }

#[derive(Debug, Clone, PartialEq)]
pub struct P {
    pub re: lz_builtins::Complex64,
    pub im: lz_builtins::Complex64,
}

pub fn main() {
    // STMT:Let
    let p = P { re: Complex64::new(1.0f64, 0.0f64), im: Complex64::new(0.0f64, 1.0f64) };
    // STMT:Let
    let mag: lz_builtins::Complex64 = ((p.re).clone() * (p.re).clone()).clone() + ((p.im).clone() * (p.im).clone()).clone();
    // STMT:Expr
    println!("{:?}", mag);
}

const __name__: &str = "main";

const __file__: &str = "g7_complex_struct.lz";

const __package__: &str = "r2";

const __path__: &str = ".fist-wf-20260926\\r2";

const __doc__: &str = "";

const __is_macro__: bool = false;

