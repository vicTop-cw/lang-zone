
#[allow(unused_imports)]
#[allow(unused_variables)]
#[allow(dead_code)]
#[allow(non_snake_case)]

use std::collections::{HashMap, HashSet};
use std::any::Any;
use std::rc::Rc;
use std::sync::Arc;
use std::fmt::Debug;
use std::fmt::Display;

use lz_builtins::*;

const __name__: &str = "main";

const __file__: &str = "bigint_min.lz";

const __package__: &str = "bug-C-bigint-const-nonconst-op-e0015";

const __path__: &str = "FIND_BUG\\hunt-20260926\\bug-C-bigint-const-nonconst-op-e0015";

const __doc__: &str = "";

const __is_macro__: bool = false;

static x: std::sync::LazyLock<lz_builtins::BigInt> = std::sync::LazyLock::new(|| lz_builtins::BigInt::from(12345678901234567890i128));

static y: std::sync::LazyLock<lz_builtins::BigInt> = std::sync::LazyLock::new(|| (*x).clone() * 100i64);

pub fn main() {
    // STMT:Expr
    return println!("{:?}", (*y).clone());
}
