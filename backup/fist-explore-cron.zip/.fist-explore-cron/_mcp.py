# lz explore-cron MCP stdio driver (Python). cwd = E:\IDEProjects\AI\lang-zone\.fist-explore-cron
# Usage: python _mcp.py <requests.json>
# requests.json = [ {"name": "...", "arguments": {...}, "method": "tools/call"}, ... ]
import json
import os
import subprocess
import sys

# 首选：已注册的 fist-mbt CLI（`fist-mbt serve`，黑盒用法，不依赖上游构建产物路径）。
# 备选：FIST-Mbt 的构建产物 main.js（上游重建期间会消失，故不再作为默认）。
USE_CLI = os.environ.get("LZ_FIST_MCP_CLI", "1") != "0"
# 注：fist-mbt 是 WindowsApps shim，Python subprocess 不能直接拉起，需经 cmd /c
SERVER_CMD = ["cmd", "/c", "fist-mbt serve"] if USE_CLI else ["node", r"E:\IDEProjects\AI\FIST-Mbt\_build\js\debug\build\cmd\main\main.js"]
META = {
    "io.modelcontextprotocol/protocolVersion": "2026-07-28",
    "io.modelcontextprotocol/clientCapabilities": {},
    "io.modelcontextprotocol/clientInfo": {"name": "lang-zone-explore-cron", "version": "1.0.0"},
}

req_file = sys.argv[1] if len(sys.argv) > 1 else None
if not req_file:
    print("usage: python _mcp.py <requests.json>")
    sys.exit(2)

with open(req_file, "r", encoding="utf-8") as f:
    reqs = json.load(f)

lines = []
for i, r in enumerate(reqs):
    method = r.get("method", "tools/call")
    params = {"_meta": META}
    if method == "tools/call":
        params["name"] = r["name"]
        params["arguments"] = r.get("arguments", {})
    else:
        params.update(r.get("params", {}))
    msg = {"jsonrpc": "2.0", "id": str(i), "method": method, "params": params}
    lines.append(json.dumps(msg, ensure_ascii=False))

stdin_data = "\n".join(lines) + "\n"
try:
    res = subprocess.run(
        SERVER_CMD,
        input=stdin_data,
        capture_output=True,
        text=True,
        encoding="utf-8",
        errors="replace",
        timeout=90,
    )
    stdout, stderr = res.stdout, res.stderr
except subprocess.TimeoutExpired as e:
    stdout = e.stdout or ""
    stderr = e.stderr or ""

raw = [l for l in stdout.splitlines() if l.strip()]
out = []
for i, line in enumerate(raw):
    label = reqs[i].get("name", reqs[i].get("method")) if i < len(reqs) else "?"
    try:
        parsed = json.loads(line)
    except Exception:
        out.append(f"#{i} {label} RAW {line[:400]}")
        continue
    payload = parsed.get("error") or parsed.get("result")
    if isinstance(payload, dict) and isinstance(payload.get("content"), list):
        payload = "\n".join((c.get("text") or "") for c in payload["content"])
    if not isinstance(payload, str):
        payload = json.dumps(payload, ensure_ascii=False)
    out.append(f"#{i} {label} -> {payload[:400000]}")

print("\n".join(out))
if stderr.strip():
    print("--- stderr ---")
    print(stderr.strip()[:2000])
