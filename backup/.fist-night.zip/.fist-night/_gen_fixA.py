import json
NOW="2026-09-27T03:20:00+08:00"
leaves=["T0r8.1.1","T0r8.1.2","T0r8.2.1","T0r8.2.2","T0r8.3.1","T0r8.3.2","T0r8.4.1","T0r8.4.2"]
reqs=[]
for t in leaves:
    reqs.append({"name":"claim","arguments":{"task_id":t,"assignee":"night-executor","now":NOW}})
for t in leaves:
    reqs.append({"name":"omega_spec_create","arguments":{"task_id":t,"author":"human_steward","content":"[R1-修复] "+t+" 执行规格：遗留集零触碰前提下完成本叶闭环（复现取证->最小修复->隔离副本实跑回归->挂账/收口），全证据落 .fist-night/","now":NOW}})
for t in leaves:
    reqs.append({"name":"omega_spec_review","arguments":{"task_id":t,"reviewer":"verifier","verdict":"approve","reason":"规格明确、红线（遗留集零触碰/隔离副本验证）已写入","now":NOW}})
open("_req_fixA.json","w",encoding="utf-8").write(json.dumps(reqs,ensure_ascii=False))
print(len(reqs))
