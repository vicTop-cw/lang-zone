import json
NOW = "2026-09-27T00:40:00+08:00"
S = "<0x01>PATH<0x01>"
deliv = {
 "T0.1.1": "标记盘点(1/2): src 全量 115 个 .rs，TODO/FIXME/HACK 共 7 处；unwrap() 密度 top3 = src/util/mini_toml.rs:106、src/bridge/std.rs:53、src/ir/codegen/mod.rs:37；证据 .fist-night/_gate_baseline.log",
 "T0.1.2": "标记盘点(2/2): 高危面收敛至 codegen/bridge 两域；PATH_SENTINEL 常量 3 处（src/ir/builder.rs:4975、src/ir/codegen/mod.rs:11307/12717），builder 侧产出、codegen 表达式侧已剥离、Call 侧未剥离；证据 .fist-night/memory/bugs.md",
 "T0.2.1": "测试暴露(1/2): cargo test --no-fail-fast 实跑 = 676 passed / 4 failed / 680 total，2 个 target 全红（tests/find_bug_bugs.rs、tests/lz_ir_bootstrap.rs）；证据 .fist-night/_gate_baseline.log",
 "T0.2.2": "测试暴露(2/2): 失败清单 4 条 = core_compose_ok(E0282)、sb001_time_method(E0433)、ty004_params_type_erase(unknown token U+0001)、lz_emit_rs_lz_matches_native_codegen(unknown token U+0001)；证据 .fist-night/_gate_baseline.log",
 "T0.3.1": "读码狩猎+差分(1/2): BUG-N1 确诊——builder.rs:4974 PathAccess 注入哨兵 " + S + "，codegen/mod.rs:10255-10347 Call 发射点未剥离，产物 Type::" + S + "new()；证据 .fist-night/memory/bugs.md",
 "T0.3.2": "读码狩猎+差分(2/2): BUG-N2 确诊——codegen/mod.rs:9640 白名单 types.contains(type_name) 被哨兵前缀绕过致 std 模块链拦截失效；BUG-N3 确诊——compose 闭包参数缺标注 E0282（语义级）；证据 .fist-night/memory/bugs.md",
 "T0.4.1": "确诊入账(1/2): BUG-N1 最小补丁 .fist-night/patches/BUG-N1_call_path_sentinel.patch（4 hunk / <=20 行 / 不动语义），git apply --check 通过（未应用：落点属遗留集，夜间零触碰）",
 "T0.4.2": "确诊入账(2/2): 缺陷账 .fist-night/memory/bugs.md 建账，入账 3 单（BUG-N1 critical / BUG-N2 high / BUG-N3 medium），BUG-N4 与 N1 同根因合并撤回不重复计账",
}
reqs = []
for tid, d in deliv.items():
    reqs.append({"name": "claim", "arguments": {"task_id": tid, "assignee": "night-executor", "now": NOW}})
    reqs.append({"name": "execute", "arguments": {"task_id": tid, "deliverable": d, "now": NOW}})
    reqs.append({"name": "submit", "arguments": {"task_id": tid, "now": NOW}})
    reqs.append({"name": "verify", "arguments": {"task_id": tid, "verifier": "night-gate", "now": NOW}})
reqs.append({"name": "verify", "arguments": {"task_id": "T0", "verifier": "night-gate", "now": NOW}})
reqs.append({"name": "archive", "arguments": {"task_id": "T0", "by": "night-gate", "now": NOW}})
open("_req_t0_leaves.json", "w", encoding="utf-8").write(json.dumps(reqs, ensure_ascii=False))
print(len(reqs))
