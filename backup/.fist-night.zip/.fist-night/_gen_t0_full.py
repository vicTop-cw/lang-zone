import json
NOW = "2026-09-27T00:45:00+08:00"
S = "<0x01>PATH<0x01>"
deliv = {
 "T0.1.1": "标记盘点(1/2): src 全量 115 个 .rs，TODO/FIXME/HACK 共 7 处；unwrap() 密度 top3 = src/util/mini_toml.rs:106、src/bridge/std.rs:53、src/ir/codegen/mod.rs:37；证据 .fist-night/_gate_baseline.log",
 "T0.1.2": "标记盘点(2/2): 高危面收敛至 codegen/bridge 两域；PATH_SENTINEL 常量 3 处（src/ir/builder.rs:4975、src/ir/codegen/mod.rs:11307/12717），builder 侧产出、codegen 表达式侧已剥离、Call 侧未剥离；证据 .fist-night/memory/bugs.md",
 "T0.2.1": "测试暴露(1/2): cargo test --no-fail-fast 实跑 = 676 passed / 4 failed / 680 total，2 个 target 全红（tests/find_bug_bugs.rs、tests/lz_ir_bootstrap.rs）；证据 .fist-night/_gate_baseline.log",
 "T0.2.2": "测试暴露(2/2): 失败清单 4 条 = core_compose_ok(E0282)、sb001_time_method(E0433)、ty004_params_type_erase(unknown token U+0001)、lz_emit_rs_lz_matches_native_codegen(unknown token U+0001)；证据 .fist-night/_gate_baseline.log",
 "T0.3.1": "读码狩猎+差分(1/2): BUG-N1 确诊——builder.rs:4974 PathAccess 注入哨兵 " + S + "，codegen/mod.rs:10255-10347 Call 发射点未剥离，产物 Type::" + S + "new()；证据 .fist-night/memory/bugs.md",
 "T0.3.2": "读码狩猎+差分(2/2): BUG-N2 确诊——codegen/mod.rs:9640 白名单 types.contains(type_name) 被哨兵前缀绕过致 std 模块链拦截失效；BUG-N3 确诊——compose 闭包参数缺标注 E0282（语义级）；证据 .fist-night/memory/bugs.md",
 "T0.4.1": "确诊入账(1/2): BUG-N1 最小补丁 .fist-night/patches/BUG-N1_call_path_sentinel.patch（4 hunk / <=20 行 / 不动语义），git apply --check 通过（未应用：落点属遗留集，夜间零触碰）",
 "T0.4.2": "确诊入账(2/2): 缺陷账 .fist-night/memory/bugs.md 建账，入账 3 单（BUG-N1 critical / BUG-N2 high / BUG-N3 medium），BUG-N4 与 N1 同根因合并撤回不重复计账",
}
bugs = [
 ("[夜巡R1] src/ir/codegen/mod.rs Call 发射点未剥离 PathAccess 哨兵，产物含 U+0001 不可编译",
  "复现: cargo test --test find_bug_bugs ty004_params_type_erase / cargo test --test lz_ir_bootstrap lz_emit_rs_lz_matches_native_codegen\n"
  "报错: error: unknown start of token: \\u{1} -> __Params::<U+0001>PATH<U+0001>new() / String::<U+0001>PATH<U+0001>new()\n"
  "根因: src/ir/builder.rs:4974-4981 把 PathAccess 降级为 FieldAccess{field:\\u{1}PATH\\u{1}+segment}；"
  "codegen/mod.rs:12704-12822 表达式发射点已剥离，但 10255-10347 Call 发射点把含哨兵 field 原样拼进 format!(\"{}::{}({})\",base_s,field,..) (10347)。\n"
  "补丁: .fist-night/patches/BUG-N1_call_path_sentinel.patch（git apply --check 通过，未应用——落点属遗留集，夜间零触碰）",
  "critical"),
 ("[夜巡R1] src/ir/codegen/mod.rs:9640 std 模块链拦截被 PathAccess 哨兵绕过，time::Duration::fromMillis 未映射",
  "复现: cargo test --test find_bug_bugs sb001_time_method\n"
  "报错: error[E0433]: cannot find module or crate `time` in this scope -> 产物 time::Duration::fromMillis(1500i64)\n"
  "根因: .lz 写 time::Duration.fromMillis(1500)，time::Duration 是 PathAccess -> builder.rs:4978 段名带 \\u{1}PATH\\u{1} 前缀；"
  "codegen/mod.rs:9640 types.contains(&type_name.as_str()) 与白名单 [\"Duration\",\"Instant\"] 精确匹配失败 -> 拦截不生效，camelCase->snake_case 与 std:: 前缀均未施加。\n"
  "修复: 9640 前 trim_start_matches(PATH_SENTINEL) 得到 type_name_s，匹配/输出/u64 后缀处理统一改用 type_name_s（与 BUG-N1 同源）。",
  "high"),
 ("[夜巡R1] 泛型 compose 闭包参数缺类型标注 -> E0282（语义级，需人工定夺）",
  "复现: cargo test --test find_bug_bugs core_compose_ok\n"
  "报错: error[E0282]: type annotations needed @ FIND_BUG/core/compose.rs:55\n"
  "产物: compose<a,b,c>(f: impl Fn(b)->c, g: impl Fn(a)->b) -> Box<dyn Fn(a)->c)；调用点 compose(move |x| {(x).clone()*2i64}, move |x| {LzAdd::__add__(x,3i64)})\n"
  "根因: .lz 中 |x| f(g(x)) 无参数类型标注，Rust 无法从 impl Fn(a)->b 反推 a。\n"
  "候选: ① 调用点补 turbofish ② 生成闭包时按形参 fn(a)->b 反向标注 ③ 改具名泛型 F/G 靠实参推断。属语义/设计决策，卡 C 禁区只挂账不修。",
  "medium"),
]
reqs = []
for summary, detail, sev in bugs:
    reqs.append({"name": "report_bug", "arguments": {"project_dir": ".", "summary": summary,
                 "detail": detail, "severity": sev, "reported_by": "night-executor",
                 "publish_task": True, "now": NOW}})
for i,(tid, d) in enumerate(deliv.items()):
    if tid != "T0.1.1":
        reqs.append({"name": "omega_spec_create", "arguments": {"task_id": tid, "author": "human_steward",
                 "content": d, "now": NOW}})
    if tid != "T0.1.1":
        reqs.append({"name": "omega_spec_review", "arguments": {"task_id": tid, "reviewer": "verifier",
                 "verdict": "approve", "reason": "证据齐备，最小复现+根因+相对路径证据", "now": NOW}})
    reqs.append({"name": "execute", "arguments": {"task_id": tid, "deliverable": d, "now": NOW}})
    reqs.append({"name": "omega_result_verify", "arguments": {"task_id": tid, "reviewer": "verifier",
                 "verdict": "pass", "reason": "交付物与门禁日志可核对", "now": NOW}})
    reqs.append({"name": "submit", "arguments": {"task_id": tid, "now": NOW}})
    reqs.append({"name": "verify", "arguments": {"task_id": tid, "verifier": "human_steward", "now": NOW}})
reqs.append({"name": "verify", "arguments": {"task_id": "T0", "verifier": "human_steward", "now": NOW}})
reqs.append({"name": "archive", "arguments": {"task_id": "T0", "by": "human_steward", "now": NOW}})
open("_req_t0_full.json", "w", encoding="utf-8").write(json.dumps(reqs, ensure_ascii=False))
print(len(reqs))
