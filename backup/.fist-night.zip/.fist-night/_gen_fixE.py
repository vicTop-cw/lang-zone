import json
NOW="2026-09-27T03:49:00+08:00"
parents = {
"T0r8.1":"BUG-N1 闭环：隔离副本复现取证 + 补丁实跑回归，2 个用例 FAILED->PASS（ty004_params_type_erase、lz_emit_rs_lz_matches_native_codegen）",
"T0r8.2":"BUG-N2 闭环：最小补丁构造 + 隔离副本两轮实跑，暴露并修掉次级缺陷（方法段哨兵），sb001_time_method FAILED->PASS",
"T0r8.3":"BUG-N3 闭环：语义级 E0282 只挂账不修；新增并经实跑验证候选④（语料级调用点标注），补丁备妥待人工定夺",
"T0r8.4":"收口：合并补丁 BUG-N1N2_path_sentinel.patch（git apply --check 通过）+ golden 快照影响评估（无漂移，无需再对齐）+ 门禁对照 676/4/680 -> 679/1/680",
}
reqs=[]
for t in parents: reqs.append({"name":"reject","arguments":{"task_id":t,"reviewer":"verifier","reason":"父层缺交付物，回退补证（子叶已全绿）","now":NOW}})
for t in parents: reqs.append({"name":"retry","arguments":{"task_id":t,"now":NOW}})
for t,pd in parents.items(): reqs.append({"name":"execute","arguments":{"task_id":t,"deliverable":pd,"now":NOW}})
open("_req_fixE.json","w",encoding="utf-8").write(json.dumps(reqs,ensure_ascii=False))
print(len(reqs))
