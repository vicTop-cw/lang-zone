import json
NOW="2026-09-27T03:51:00+08:00"
parents=["T0r8.1","T0r8.2","T0r8.3","T0r8.4"]
reqs=[]
for t in parents: reqs.append({"name":"omega_result_verify","arguments":{"task_id":t,"reviewer":"verifier","verdict":"pass","reason":"子叶已 verify，父层交付物与隔离副本实跑日志可核对","now":NOW}})
for t in parents: reqs.append({"name":"submit","arguments":{"task_id":t,"now":NOW}})
for t in parents: reqs.append({"name":"verify","arguments":{"task_id":t,"verifier":"human_steward","now":NOW}})
open("_req_fixF.json","w",encoding="utf-8").write(json.dumps(reqs,ensure_ascii=False))
print(len(reqs))
