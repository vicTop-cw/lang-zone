
// ── LZ rustc link recipe (BUG-10: lz_builtins re-exports num-bigint/num-complex) ──
// To compile & run this generated file in isolation:
//   rustc --edition 2021 --extern lz_builtins=<rlib> -L dependency=<deps_dir> -O <this_file>.rs
//   <rlib>     = liblz_builtins.rlib (build it: `cargo build -p lz_builtins`)
//   <deps_dir> = the directory containing that rlib (e.g. <workspace>/target/debug/deps)
// Omitting -L gives error[E0463] even if this program never uses BigInt/Complex.
// ─────────────────────────────────────────────────────────────────────────────────────

#[allow(unused_imports)]
#[allow(unused_variables)]
#[allow(dead_code)]
#[allow(non_snake_case)]

use std::collections::{HashMap, HashSet};
use std::any::Any;
use std::rc::Rc;
use std::sync::Arc;
use std::fmt::Debug;
use std::fmt::Display;

use lz_builtins::*;

#[allow(non_snake_case)] #[allow(dead_code)]
fn println(__a0: i64) -> i64 { i64::MAX }

pub fn main() {
    // STMT:Expr
    println!("{:?}", "plain".to_string());
    // STMT:Let
    let n: i64 = 42i64;
    // STMT:Expr
    println!("{:?}", format!("fstring {:?}", n));
    // STMT:Expr
    println!("{:?}", n);
    // STMT:Expr
    println!("{:?}", true);
    // STMT:Expr
    println!("{:?}", vec![1i64, 2i64, 3i64]);
    // STMT:Let
    let s: String = "str".to_string();
    // STMT:Expr
    println!("{:?}", s);
    // STMT:Expr
    println!("{:?}", "done".to_string());
}

const __name__: &str = "main";

const __file__: &str = "probe_print.lz";

const __package__: &str = "perf";

const __path__: &str = ".fist-perf-20261008\\perf";

const __doc__: &str = "";

const __is_macro__: bool = false;

