
// ── LZ rustc link recipe (BUG-10: lz_builtins re-exports num-bigint/num-complex) ──
// To compile & run this generated file in isolation:
//   rustc --edition 2021 --extern lz_builtins=<rlib> -L dependency=<deps_dir> -O <this_file>.rs
//   <rlib>     = liblz_builtins.rlib (build it: `cargo build -p lz_builtins`)
//   <deps_dir> = the directory containing that rlib (e.g. <workspace>/target/debug/deps)
// Omitting -L gives error[E0463] even if this program never uses BigInt/Complex.
// ─────────────────────────────────────────────────────────────────────────────────────

#[allow(unused_imports)]
#[allow(unused_variables)]
#[allow(dead_code)]
#[allow(non_snake_case)]

use std::collections::{HashMap, HashSet};
use std::any::Any;
use std::rc::Rc;
use std::sync::Arc;
use std::fmt::Debug;
use std::fmt::Display;

use lz_builtins::*;

pub fn fib(n: i64) -> i64 {
    return if n <= 1i64 { n } else { fib(n - 1i64) + fib(n - 2i64) };
}

pub fn sieve(n: i64) -> i64 {
    let mut count: i64 = 0i64;
    let mut is_prime: Vec<bool> = Vec::with_capacity(((n + 1i64)).max(0) as usize);
    for i in (0..n + 1i64).into_iter() {
        is_prime.push(true);
    }
    is_prime[((0i64) as usize)] = false;
    is_prime[((1i64) as usize)] = false;
    let mut p: i64 = 2i64;
    while p * p <= n {
        if is_prime[((p) as usize)] {
            let mut multiple: i64 = p * p;
            while multiple <= n {
                is_prime[((multiple) as usize)] = false;
                multiple = multiple + p;
            }
        };
        p = p + 1i64;
    }
    for i in (0..n + 1i64).into_iter() {
        if is_prime[((i) as usize)] {
            count = count + 1i64;
        };
    }
    return count;
}

pub fn sum_to(n: i64) -> i64 {
    let mut acc: i64 = 0i64;
    let mut i: i64 = 1i64;
    while i <= n {
        acc = acc + i * i;
        i = i + 1i64;
    }
    return acc;
}

pub fn main() {
    let f: i64 = fib(32i64);
    println!("{}", format!("fib(32) = {:?}", f));
    let c: i64 = sieve(300000i64);
    println!("{}", format!("sieve(300000) = {:?} primes", c));
    let s: i64 = sum_to(3000000i64);
    println!("{}", format!("sum_to(3000000) = {:?}", s));
}

const __name__: &str = "main";

const __file__: &str = "bench.lz";

const __package__: &str = "out";

const __path__: &str = "E:\\IDEProjects\\AI\\lang-zone\\.fist-perf-20261008\\perf\\out";

const __doc__: &str = "";

const __is_macro__: bool = false;

