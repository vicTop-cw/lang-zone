fn sieve(n: i64) -> i64 {
    let mut is_prime: Vec<bool> = Vec::with_capacity((n + 1) as usize);
    for _ in 0..=n {
        is_prime.push(true);
    }
    is_prime[0] = false;
    is_prime[1] = false;
    let mut p: i64 = 2;
    while p * p <= n {
        if is_prime[p as usize] {
            let mut multiple = p * p;
            while multiple <= n {
                is_prime[multiple as usize] = false;
                multiple += p;
            }
        }
        p += 1;
    }
    let mut count: i64 = 0;
    for i in 0..=n {
        if is_prime[i as usize] {
            count += 1;
        }
    }
    count
}

fn main() {
    println!("{}", sieve(4000000));
}
