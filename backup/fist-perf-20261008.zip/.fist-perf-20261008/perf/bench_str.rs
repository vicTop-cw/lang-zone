fn main() {
    let mut s = String::new();
    let mut i: i64 = 0;
    while i < 20000 {
        s.push_str("ab");
        i += 1;
    }
    println!("{}", s.len());
}
