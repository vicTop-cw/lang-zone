// 手写 Rust 锚点：与 bench.lz 逐算法等价（fib + sieve + sum_to），release -O 编译。
fn fib(n: i64) -> i64 {
    if n <= 1 {
        n
    } else {
        fib(n - 1) + fib(n - 2)
    }
}

fn sieve(n: i64) -> i64 {
    let mut is_prime: Vec<bool> = Vec::with_capacity((n + 1) as usize);
    for _ in 0..=n {
        is_prime.push(true);
    }
    is_prime[0] = false;
    is_prime[1] = false;
    let mut p: i64 = 2;
    while p * p <= n {
        if is_prime[p as usize] {
            let mut multiple = p * p;
            while multiple <= n {
                is_prime[multiple as usize] = false;
                multiple += p;
            }
        }
        p += 1;
    }
    let mut count: i64 = 0;
    for i in 0..=n {
        if is_prime[i as usize] {
            count += 1;
        }
    }
    count
}

fn sum_to(n: i64) -> i64 {
    let mut acc: i64 = 0;
    let mut i: i64 = 1;
    while i <= n {
        acc += i * i;
        i += 1;
    }
    acc
}

fn main() {
    let f = fib(32);
    println!("fib(32) = {}", f);
    let c = sieve(300000);
    println!("sieve(300000) = {} primes", c);
    let s = sum_to(3000000);
    println!("sum_to(3000000) = {}", s);
}