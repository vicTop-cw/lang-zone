
// ── LZ rustc link recipe (BUG-10: lz_builtins re-exports num-bigint/num-complex) ──
// To compile & run this generated file in isolation:
//   rustc --edition 2021 --extern lz_builtins=<rlib> -L dependency=<deps_dir> -O <this_file>.rs
//   <rlib>     = liblz_builtins.rlib (build it: `cargo build -p lz_builtins`)
//   <deps_dir> = the directory containing that rlib (e.g. <workspace>/target/debug/deps)
// Omitting -L gives error[E0463] even if this program never uses BigInt/Complex.
// ─────────────────────────────────────────────────────────────────────────────────────

#[allow(unused_imports)]
#[allow(unused_variables)]
#[allow(dead_code)]
#[allow(non_snake_case)]

use std::collections::{HashMap, HashSet};
use std::any::Any;
use std::rc::Rc;
use std::sync::Arc;
use std::fmt::Debug;
use std::fmt::Display;

use lz_builtins::*;

pub fn fib(n: i64) -> i64 {
    // STMT:Expr
    return if n <= 1i64 { n } else { fib(n - 1i64) + fib(n - 2i64) };
}

pub fn sieve(n: i64) -> i64 {
    // STMT:Let
    let mut count: i64 = 0i64;
    // STMT:Let
    let mut is_prime: Vec<bool> = Vec::new();
    // STMT:For
    for i in (0..n + 1i64).into_iter() {
        // STMT:Expr
        is_prime.push(true);
    }
    // STMT:Other
    is_prime[((0i64) as usize)] = false;
    // STMT:Other
    is_prime[((1i64) as usize)] = false;
    // STMT:Let
    let mut p: i64 = 2i64;
    // STMT:Other
    while p * p <= n {
        // STMT:Expr
        if is_prime[((p) as usize)] {
            // STMT:Let
            let mut multiple: i64 = p * p;
            // STMT:Other
            while multiple <= n {
                // STMT:Other
                is_prime[((multiple) as usize)] = false;
                // STMT:Let
                multiple = multiple + p;
            }
        } else { ()};
        // STMT:Let
        p = p + 1i64;
    }
    // STMT:For
    for i in (0..n + 1i64).into_iter() {
        // STMT:Expr
        if is_prime[((i) as usize)] {
            // STMT:Other
            count = count + 1i64;
        } else { ()};
    }
    // STMT:Expr
    return count;
}

pub fn sum_to(n: i64) -> i64 {
    // STMT:Let
    let mut acc: i64 = 0i64;
    // STMT:Let
    let mut i: i64 = 1i64;
    // STMT:Other
    while i <= n {
        // STMT:Let
        acc = acc + i * i;
        // STMT:Let
        i = i + 1i64;
    }
    // STMT:Expr
    return acc;
}

pub fn main() {
    // STMT:Let
    let f: i64 = fib(32i64);
    // STMT:Expr
    println!("{:?}", format!("fib(32) = {:?}", f));
    // STMT:Let
    let c: i64 = sieve(300000i64);
    // STMT:Expr
    println!("{:?}", format!("sieve(300000) = {:?} primes", c));
    // STMT:Let
    let s: i64 = sum_to(3000000i64);
    // STMT:Expr
    println!("{:?}", format!("sum_to(3000000) = {:?}", s));
}

const __name__: &str = "main";

const __file__: &str = "bench.lz";

const __package__: &str = "out";

const __path__: &str = "E:\\IDEProjects\\AI\\lang-zone\\.fist-perf-20261008\\perf\\out";

const __doc__: &str = "";

const __is_macro__: bool = false;

