use std::fmt::Display;
fn fib(n: i64) -> i64 {
    if n <= 1 {
        n
    } else {
        fib(n - 1) + fib(n - 2)
    }
}
fn sieve(n: usize) -> usize {
    let mut is_prime = vec![true; n + 1];
    is_prime[0] = false;
    is_prime[1] = false;
    let mut p = 2;
    while p * p <= n {
        if is_prime[p] {
            let mut m = p * p;
            while m <= n {
                is_prime[m] = false;
                m += p;
            }
        }
        p += 1;
    }
    is_prime.iter().filter(|&&x| x).count()
}
fn sum_to(n: i64) -> i64 {
    let mut acc = 0;
    for i in 1..=n {
        acc += i * i;
    }
    acc
}
fn main() {
    let f = fib(32);
    println!("fib(32) = {}", f);
    let c = sieve(300_000);
    println!("sieve(300000) = {} primes", c);
    let s = sum_to(3_000_000);
    println!("sum_to(3000000) = {}", s);
}
