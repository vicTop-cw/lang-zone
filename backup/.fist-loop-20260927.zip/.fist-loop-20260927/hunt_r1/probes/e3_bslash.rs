
#[allow(unused_imports)]
#[allow(unused_variables)]
#[allow(dead_code)]
#[allow(non_snake_case)]

use std::collections::{HashMap, HashSet};
use std::any::Any;
use std::rc::Rc;
use std::sync::Arc;
use std::fmt::Debug;
use std::fmt::Display;

use lz_builtins::*;

const __name__: &str = "main";

const __file__: &str = "e3_bslash.lz";

const __package__: &str = "probes";

const __path__: &str = ".fist-loop-20260927/hunt_r1/probes";

const __doc__: &str = "";

const __is_macro__: bool = false;

const s: &str = "a\\b";

pub fn main() {
    // STMT:Expr
    return println!("{:?}", "a\\b".to_string());
}
