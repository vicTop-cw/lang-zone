
#[allow(unused_imports)]
#[allow(unused_variables)]
#[allow(dead_code)]
#[allow(non_snake_case)]

use std::collections::{HashMap, HashSet};
use std::any::Any;
use std::rc::Rc;
use std::sync::Arc;
use std::fmt::Debug;
use std::fmt::Display;

use lz_builtins::*;

#[allow(non_snake_case)] #[allow(dead_code)]
fn println(__a0: i64) -> i64 { i64::MAX }

pub fn main() {
    // STMT:Let
    let a: i64 = 31i64;
    // STMT:Let
    let b: i64 = 10i64;
    // STMT:Let
    let c: i64 = 1000i64;
    // STMT:Let
    let d: f64 = 10000000000.0f64;
    // STMT:Let
    let e: f64 = 0.0015f64;
    // STMT:Expr
    println!("{:?}", a);
    // STMT:Expr
    println!("{:?}", b);
    // STMT:Expr
    println!("{:?}", c);
    // STMT:Expr
    println!("{:?}", d);
    // STMT:Expr
    println!("{:?}", e);
}

const __name__: &str = "main";

const __file__: &str = "n06_num_literals.lz";

const __package__: &str = "probes";

const __path__: &str = "E:\\IDEProjects\\AI\\lang-zone\\.fist-loop-20260927\\hunt_r1\\probes";

const __doc__: &str = "";

const __is_macro__: bool = false;

