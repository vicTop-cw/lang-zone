
#[allow(unused_imports)]
#[allow(unused_variables)]
#[allow(dead_code)]
#[allow(non_snake_case)]

use std::collections::{HashMap, HashSet};
use std::any::Any;
use std::rc::Rc;
use std::sync::Arc;
use std::fmt::Debug;
use std::fmt::Display;

use lz_builtins::*;

#[allow(non_snake_case)] #[allow(dead_code)]
fn println(__a0: i64) -> i64 { i64::MAX }

pub fn main() {
    // STMT:Let
    let mut s: String = "\u{4e2d}\u{6587}\u{5b57}\u{7b26}\u{4e32} hello".to_string();
    // STMT:Expr
    println!("{:?}", (s.len() as i64));
    // STMT:Expr
    println!("{:?}", s);
    // STMT:Let
    let mut c: String = "\u{4e2d}".to_string();
    // STMT:Expr
    println!("{:?}", (c.len() as i64));
    // STMT:Expr
    println!("{:?}", c);
}

const __name__: &str = "main";

const __file__: &str = "p11_unicode.lz";

const __package__: &str = "probes";

const __path__: &str = "E:\\IDEProjects\\AI\\lang-zone\\.fist-loop-20260927\\hunt_r1\\probes";

const __doc__: &str = "";

const __is_macro__: bool = false;

