
#[allow(unused_imports)]
#[allow(unused_variables)]
#[allow(dead_code)]
#[allow(non_snake_case)]

use std::collections::{HashMap, HashSet};
use std::any::Any;
use std::rc::Rc;
use std::sync::Arc;
use std::fmt::Debug;
use std::fmt::Display;

use lz_builtins::*;

#[allow(non_snake_case)] #[allow(dead_code)]
fn println(__a0: i64) -> i64 { i64::MAX }

pub fn main() {
    // STMT:Let
    let s: String = "abc".to_string();
    // STMT:Expr
    println!("{:?}", {let __cs: Vec<char> = (s).chars().collect(); let __i = ((0i64 - 1i64) as usize); if __i >= __cs.len() { '\0' as i64 } else { __cs[__i] as i64 }});
}

const __name__: &str = "main";

const __file__: &str = "m23_str_idx_neg.lz";

const __package__: &str = "probes";

const __path__: &str = "E:\\IDEProjects\\AI\\lang-zone\\.fist-loop-20260927\\hunt_r1\\probes";

const __doc__: &str = "";

const __is_macro__: bool = false;

