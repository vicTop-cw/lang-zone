
#[allow(unused_imports)]
#[allow(unused_variables)]
#[allow(dead_code)]
#[allow(non_snake_case)]

use std::collections::{HashMap, HashSet};
use std::any::Any;
use std::rc::Rc;
use std::sync::Arc;
use std::fmt::Debug;
use std::fmt::Display;

use lz_builtins::*;

pub fn hello_embed() -> i64 {
    println!("hello from embed"); 42
}

pub fn main() {
    // STMT:Let
    let v: i64 = hello_embed();
    // STMT:Expr
    println!("{:?}", "embed returned: ".to_string());
    // STMT:Expr
    println!("{:?}", v);
}

const __name__: &str = "main";

const __file__: &str = "zz_demo_copy.lz";

const __package__: &str = "probes";

const __path__: &str = "E:\\IDEProjects\\AI\\lang-zone\\.fist-loop-20260927\\hunt_r1\\probes";

const __doc__: &str = "";

const __is_macro__: bool = false;

