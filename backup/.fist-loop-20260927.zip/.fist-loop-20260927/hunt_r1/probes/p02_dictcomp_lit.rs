
#[allow(unused_imports)]
#[allow(unused_variables)]
#[allow(dead_code)]
#[allow(non_snake_case)]

use std::collections::{HashMap, HashSet};
use std::collections::BTreeMap;
use std::any::Any;
use std::rc::Rc;
use std::sync::Arc;
use std::fmt::Debug;
use std::fmt::Display;

use lz_builtins::*;

const __name__: &str = "main";

const __file__: &str = "p02_dictcomp_lit.lz";

const __package__: &str = "probes";

const __path__: &str = "E:\\IDEProjects\\AI\\lang-zone\\.fist-loop-20260927\\hunt_r1\\probes";

const __doc__: &str = "";

const __is_macro__: bool = false;

static d: std::sync::LazyLock<BTreeMap<String, i64>> = std::sync::LazyLock::new(|| std::collections::BTreeMap::from([("a".to_string(), 1i64), ("b".to_string(), 2i64)]));

pub fn main() {
    // STMT:Expr
    return println!("{:?}", (*d).clone());
}
