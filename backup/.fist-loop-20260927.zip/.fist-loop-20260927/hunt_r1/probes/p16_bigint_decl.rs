
#[allow(unused_imports)]
#[allow(unused_variables)]
#[allow(dead_code)]
#[allow(non_snake_case)]

use std::collections::{HashMap, HashSet};
use num_bigint::BigInt;
use std::any::Any;
use std::rc::Rc;
use std::sync::Arc;
use std::fmt::Debug;
use std::fmt::Display;

use lz_builtins::*;

#[allow(non_snake_case)] #[allow(dead_code)]
fn println(__a0: i64) -> i64 { i64::MAX }

#[derive(Debug, Clone, PartialEq)]
pub struct Big {
    pub val: num_bigint::BigInt,
}

pub fn addbig(a: num_bigint::BigInt, b: num_bigint::BigInt) -> num_bigint::BigInt {
    // STMT:Expr
    return a + b;
}

pub fn main() {
    // STMT:Expr
    println!("{:?}", 1i64);
}

const __name__: &str = "main";

const __file__: &str = "p16_bigint_decl.lz";

const __package__: &str = "probes";

const __path__: &str = "E:\\IDEProjects\\AI\\lang-zone\\.fist-loop-20260927\\hunt_r1\\probes";

const __doc__: &str = "";

const __is_macro__: bool = false;

