
#[allow(unused_imports)]
#[allow(unused_variables)]
#[allow(dead_code)]
#[allow(non_snake_case)]

use std::collections::{HashMap, HashSet};
use std::any::Any;
use std::rc::Rc;
use std::sync::Arc;
use std::fmt::Debug;
use std::fmt::Display;

use lz_builtins::*;

#[allow(non_snake_case)] #[allow(dead_code)]
fn println(__a0: i64) -> i64 { i64::MAX }

pub fn main() {
    // STMT:Expr
    println!("{:?}", 1i64);
}

const __name__: &str = "main";

const __file__: &str = "n01_bom.lz";

const __package__: &str = "probes";

const __path__: &str = ".fist-loop-20260927/hunt_r1/probes";

const __doc__: &str = "";

const __is_macro__: bool = false;

