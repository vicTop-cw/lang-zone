
#[allow(unused_imports)]
#[allow(unused_variables)]
#[allow(dead_code)]
#[allow(non_snake_case)]

use std::collections::{HashMap, HashSet};
use std::any::Any;
use std::rc::Rc;
use std::sync::Arc;
use std::fmt::Debug;
use std::fmt::Display;

use lz_builtins::*;

const __name__: &str = "main";

const __file__: &str = "complex_min.lz";

const __package__: &str = "hunt_r1";

const __path__: &str = "E:\\IDEProjects\\AI\\lang-zone\\.fist-loop-20260927\\hunt_r1";

const __doc__: &str = "";

const __is_macro__: bool = false;

static z: std::sync::LazyLock<lz_builtins::Complex64> = std::sync::LazyLock::new(|| lz_builtins::Complex64::new(1.0f64, 0.0) + (lz_builtins::Complex64::new(0.0, 2.0)).clone());

pub fn main() {
    // STMT:Expr
    return println!("{:?}", (*z).clone());
}
