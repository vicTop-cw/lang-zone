
#[allow(unused_imports)]
#[allow(unused_variables)]
#[allow(dead_code)]
#[allow(non_snake_case)]

use std::collections::{HashMap, HashSet};
use std::any::Any;
use std::rc::Rc;
use std::sync::Arc;
use std::fmt::Debug;
use std::fmt::Display;

use lz_builtins::*;

#[allow(non_snake_case)] #[allow(dead_code)]
fn println(__a0: i64) -> i64 { i64::MAX }

#[derive(Debug, Clone, PartialEq)]
pub struct Big {
    pub val: lz_builtins::BigInt,
}

pub fn make_big() -> lz_builtins::BigInt {
    // STMT:Let
    let x: lz_builtins::BigInt = lz_builtins::BigInt::from(99999999999999999999999i128);
    // STMT:Expr
    return x;
}

pub fn main() {
    // STMT:Let
    let b = Big { val: lz_builtins::BigInt::from(123456789012345678901234567890i128) };
    // STMT:Expr
    println!("{:?}", make_big());
    // STMT:Expr
    println!("{:?}", b.val);
}

const __name__: &str = "main";

const __file__: &str = "bigint_annot.lz";

const __package__: &str = "hunt_r1";

const __path__: &str = "E:\\IDEProjects\\AI\\lang-zone\\.fist-loop-20260927\\hunt_r1";

const __doc__: &str = "";

const __is_macro__: bool = false;

