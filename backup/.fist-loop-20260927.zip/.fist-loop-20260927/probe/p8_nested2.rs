
#[allow(unused_imports)]
#[allow(unused_variables)]
#[allow(dead_code)]
#[allow(non_snake_case)]

use std::collections::{HashMap, HashSet};
use std::any::Any;
use std::rc::Rc;
use std::sync::Arc;
use std::fmt::Debug;
use std::fmt::Display;

use lz_builtins::*;

pub fn outer(a: i64) -> i64 {
    // STMT:Expr
    ();
    // STMT:Expr
    return mid(a) + 1i64;
}

const __name__: &str = "main";

const __file__: &str = "p8_nested2.lz";

const __package__: &str = "";

const __path__: &str = "";

const __doc__: &str = "";

const __is_macro__: bool = false;

pub fn leaf(c: i64) -> i64 {
    // STMT:Expr
    return c * 2i64;
}

pub fn mid(b: i64) -> i64 {
    // STMT:Expr
    ();
    // STMT:Expr
    return leaf(b) + 1i64;
}

pub fn main() {
    // STMT:Expr
    return println!("{:?}", outer(3i64));
}
