
#[allow(unused_imports)]
#[allow(unused_variables)]
#[allow(dead_code)]
#[allow(non_snake_case)]

use std::collections::{HashMap, HashSet};
use std::any::Any;
use std::rc::Rc;
use std::sync::Arc;
use std::fmt::Debug;
use std::fmt::Display;

use lz_builtins::*;

pub fn f() -> Vec<i64> {
    // STMT:Let
    let xs: Vec<i64> = vec![1i64, 2i64, 3i64];
    // STMT:Expr
    return ((xs).clone()).into_iter().map(move |x| { (x).clone() * 2i64 }).collect::<Vec<_>>();
}

const __name__: &str = "main";

const __file__: &str = "p4_listcomp.lz";

const __package__: &str = "";

const __path__: &str = "";

const __doc__: &str = "";

const __is_macro__: bool = false;

pub fn main() {
    // STMT:Expr
    return println!("{:?}", f());
}
