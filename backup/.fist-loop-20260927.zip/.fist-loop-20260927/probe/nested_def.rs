
#[allow(unused_imports)]
#[allow(unused_variables)]
#[allow(dead_code)]
#[allow(non_snake_case)]

use std::collections::{HashMap, HashSet};
use std::any::Any;
use std::rc::Rc;
use std::sync::Arc;
use std::fmt::Debug;
use std::fmt::Display;

use lz_builtins::*;

pub fn outer() -> i64 {
    // STMT:Expr
    ();
    // STMT:Expr
    return inner(41i64);
}

const __name__: &str = "main";

const __file__: &str = "nested_def.lz";

const __package__: &str = "probe";

const __path__: &str = ".fist-loop-20260927/probe";

const __doc__: &str = "";

const __is_macro__: bool = false;

pub fn inner(x: i64) -> i64 {
    // STMT:Expr
    return x + 1i64;
}

pub fn main() {
    // STMT:Expr
    return println!("{:?}", outer());
}
