
#[allow(unused_imports)]
#[allow(unused_variables)]
#[allow(dead_code)]
#[allow(non_snake_case)]

use std::collections::{HashMap, HashSet};
use std::any::Any;
use std::rc::Rc;
use std::sync::Arc;
use std::fmt::Debug;
use std::fmt::Display;

use lz_builtins::*;

const __name__: &str = "main";

const __file__: &str = "p7_lambda_comp.lz";

const __package__: &str = "";

const __path__: &str = "";

const __doc__: &str = "";

const __is_macro__: bool = false;

static xs: std::sync::LazyLock<Vec<i64>> = std::sync::LazyLock::new(|| vec![1i64, 2i64, 3i64]);

static ys: std::sync::LazyLock<Vec<i64>> = std::sync::LazyLock::new(|| (vec![1i64, 2i64, 3i64]).into_iter().map(move |x| { LzAdd::__add__(x, 1i64) }).collect::<Vec<_>>());

pub fn main() {
    // STMT:Expr
    return println!("{:?}", (*ys).clone());
}
