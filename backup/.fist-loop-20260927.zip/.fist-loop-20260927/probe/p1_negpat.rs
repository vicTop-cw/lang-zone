
#[allow(unused_imports)]
#[allow(unused_variables)]
#[allow(dead_code)]
#[allow(non_snake_case)]

use std::collections::{HashMap, HashSet};
use std::any::Any;
use std::rc::Rc;
use std::sync::Arc;
use std::fmt::Debug;
use std::fmt::Display;

use lz_builtins::*;

pub fn f(x: i64) -> i64 {
    // STMT:Other
    match x.clone() {
        -1i64 => {
            // STMT:Expr
            0i64
        }
        _ => {
            // STMT:Expr
            x
        }
    }
}

const __name__: &str = "main";

const __file__: &str = "p1_negpat.lz";

const __package__: &str = "";

const __path__: &str = "";

const __doc__: &str = "";

const __is_macro__: bool = false;

pub fn main() {
    // STMT:Expr
    return println!("{:?}", f(3i64));
}
