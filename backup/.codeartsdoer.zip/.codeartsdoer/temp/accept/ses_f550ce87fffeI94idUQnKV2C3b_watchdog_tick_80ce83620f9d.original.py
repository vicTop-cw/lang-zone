import subprocess
import json
import sys

# Start the MCP server
server_path = r"E:\IDEProjects\AI\FIST-Mbt\_build\js\debug\build\cmd\main\main.js"
work_dir = r"E:\IDEProjects\AI\FIST-Mbt"

proc = subprocess.Popen(
    ["node", server_path],
    cwd=work_dir,
    stdin=subprocess.PIPE,
    stdout=subprocess.PIPE,
    stderr=subprocess.PIPE,
    text=True,
    encoding="utf-8",
    errors="replace"
)

def send_request(request):
    """Send a JSON-RPC request and return the response."""
    request_str = json.dumps(request) + "\n"
    proc.stdin.write(request_str)
    proc.stdin.flush()
    
    # Read response
    response_line = ""
    while True:
        char = proc.stdout.read(1)
        if not char:
            break
        response_line += char
        if char == "\n":
            break
    
    if response_line:
        return json.loads(response_line)
    return None

# _meta for all requests - nested inside params as "_meta" sub-object
meta_content = {
    "io.modelcontextprotocol/protocolVersion": "2026-07-28",
    "io.modelcontextprotocol/clientCapabilities": {},
    "io.modelcontextprotocol/clientInfo": { "name": "lang-zone-watchdog-cron", "version": "1.0.0" }
}

# Send tools/list to verify watchdog_tick exists - _meta nested inside params
list_request = {
    "jsonrpc": "2.0",
    "id": 2,
    "method": "tools/list",
    "params": {
        "_meta": meta_content
    }
}

print("\nSending tools/list...")
list_response = send_request(list_request)
print(f"tools/list response: {json.dumps(list_response, indent=2)}")

# Check if watchdog_tick is in the list
if list_response and "result" in list_response and "tools" in list_response["result"]:
    tools = list_response["result"]["tools"]
    tool_names = [t.get("name", "") for t in tools]
    print(f"Available tools: {tool_names}")
    
    if "watchdog_tick" not in tool_names:
        print("ERROR: watchdog_tick not found in tools list!")
        proc.terminate()
        sys.exit(1)

# Call watchdog_tick - _meta nested inside params
now = "2026-09-16T23:45:25+08:00"
tick_request = {
    "jsonrpc": "2.0",
    "id": 3,
    "method": "tools/call",
    "params": {
        "_meta": meta_content,
        "name": "watchdog_tick",
        "arguments": {
            "now": now,
            "timeout_sec": 2400,
            "namespace": "cron-auto",
            "next_created_by": "watchdog",
            "next_description": "修复 find_bug_libs 测试中被忽略的两个库（lib_json、lib_tree）的代码生成器缺陷，完成 FIND_BUG 库转正（12/12）。",
            "meta_prompt_path": "E:/IDEProjects/AI/lang-zone/Gen_Prompts"
        }
    }
}

print("\nSending watchdog_tick...")
tick_response = send_request(tick_request)
print(f"watchdog_tick response: {json.dumps(tick_response, indent=2)}")

# Extract and print the result
if tick_response and "result" in tick_response:
    result = tick_response["result"]
    print("\n=== WATCHDOG TICK RESULT ===")
    print(json.dumps(result, indent=2))
else:
    print(f"\nUnexpected response: {tick_response}")

# Clean up
proc.terminate()
proc.wait()
