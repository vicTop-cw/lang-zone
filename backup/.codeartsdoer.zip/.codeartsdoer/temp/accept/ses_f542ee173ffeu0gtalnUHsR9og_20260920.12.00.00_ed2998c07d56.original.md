# 任务提示词：修复 lib_json 和 lib_tree 代码生成器缺陷

## 任务目标

修复 find_bug_libs 测试中被忽略的两个库（lib_json、lib_tree）的代码生成器缺陷，完成 FIND_BUG 库转正（12/12）。

## 背景

**当前状态**：
- 单元测试：420 passed
- find_bug_libs：10 passed, 0 failed, 2 ignored
- 忽略测试：
  - `lib_json` — P2a 代码生成器缺陷：字符串索引类型不匹配（String 不支持直接索引，char 索引生成 i64 而非 String）
  - `lib_tree` — P2a 代码生成器缺陷：命名函数传给 `&fn(...)` 参数时未正确生成 `&(f as fn(...))`
- FIND_BUG 转正进度：10/12 已转正，2 个被忽略

**相关文件**：
- `FIND_BUG/lib_json/json.lz` — JSON 解析器源码
- `FIND_BUG/lib_json/json.rs` — 生成的 Rust 代码（有编译错误）
- `FIND_BUG/lib_tree/tree.lz` — 二叉树库源码
- `FIND_BUG/lib_tree/tree.rs` — 生成的 Rust 代码（已生成，测试忽略）
- `src/ir/codegen/mod.rs` — IR 代码生成器

## 具体要求

### 1. 修复 lib_tree 问题：命名函数传递给 `&fn(...)` 参数

**问题描述**：
`fold(tree, 0, add)` 调用生成的代码是 `fold(tree, 0, &add)`，但应该生成 `fold(tree, 0, &(add as fn(i64, i64) -> i64))`。

**根因**：
第 9330-9331 行错误地将命名函数（`add`，类型为 `Fn { ... }`）判断为已是 fn pointer，导致：
1. 没有添加 `&` 前缀
2. 没有添加 `as fn(...)` 强转

**修复位置**：`src/ir/codegen/mod.rs:9330-9331`

**修复方案**：
修改 `is_already_ref_fn` 的判断条件，排除命名函数（在 `fn_param_types` 中登记的函数）：
```rust
let is_already_ref_fn = matches!(arg, Some(a) if matches!(&a.ty, IrType::Ref(inner) if matches!(inner.as_ref(), IrType::Fn { .. })))
    || matches!(arg, Some(a) if matches!(&a.kind, ExprKind::Var(name)) && matches!(&a.ty, IrType::Fn { .. }) && !self.fn_param_types.contains_key(name));
```

关键变化：添加 `&& !self.fn_param_types.contains_key(name)` 排除命名函数。

### 2. 修复 lib_json 问题：字符串索引类型不匹配

**问题描述**：
1. `self.s[usize]` — String 不支持直接索引，需要改为 `chars().collect()[usize]`
2. `char as i64` — 某些上下文期望 `String`，但生成了 `i64`

**根因**：
1. 第 12227-12243 行的字符串索引生成逻辑仅处理了 self 路径，非 self 路径（如 `self.s.clone()[...]`）未正确处理
2. 第 12241 行的 `char as i64` 生成未考虑期望类型

**修复位置**：
- `src/ir/codegen/mod.rs:12227-12243` — 字符串索引生成逻辑
- 需要扩展处理非 self 路径的字符串索引

**修复方案**：
扩展字符串索引检测逻辑，使其能处理 `self.s.clone()[...]` 等非 self 路径的情况。同时确保根据期望类型决定生成 `char.to_string()` 还是 `char as i64`。

### 3. 验证修复

1. 运行 lib_tree 测试：
   ```bash
   cargo test --test find_bug_libs lib_tree -- --nocapture
   ```

2. 运行 lib_json 测试：
   ```bash
   cargo test --test find_bug_libs lib_json -- --nocapture
   ```

3. 运行完整 find_bug_libs 测试：
   ```bash
   cargo test --test find_bug_libs
   ```
   - 预期：12 passed, 0 failed, 0 ignored

4. 运行完整测试套件确保无回归：
   ```bash
   cargo test
   ```

## 约束

- 不要修改 `FIND_BUG/lib_json/json.lz` 和 `FIND_BUG/lib_tree/tree.lz`（仅允许调整代码生成器）
- 不要修改 `tests/find_bug_libs.rs` 的测试逻辑
- 确保修复不影响其他已转正库

## 完成标准

- [x] lib_tree 测试通过（无 fn item vs fn pointer 不匹配）
- [ ] lib_json 测试通过（无字符串索引类型不匹配）
  - 进展：已修复 `FieldAccess` 的 `Ref/MutRef` 类型推断
  - 进展：已修复 `Index` 表达式的 `Str` 类型推断
  - 进展：已修复 `MethodCall` 的枚举变体类型推断
  - 进展：已修复 `BinOp` 表达式的 `current_expected_ty` 设置
  - 待修复：字符串索引在某些上下文中仍然生成 `i64` 而不是 `String`
  - 待修复：`ParseError::UnexpectedChar` 的参数类型不匹配
- [ ] find_bug_libs 测试结果：12 passed, 0 failed, 0 ignored
- [ ] 单元测试 420 passed
- [ ] 提交修复代码，commit message 格式：`fix: 修复 lib_json 和 lib_tree 代码生成器缺陷`

## 参考

- 文件：`FIND_BUG/lib_tree/tree.rs` — 生成的 Rust 代码（第93、115行有 `&f`、`&pred` 问题）
- 文件：`FIND_BUG/lib_json/json.rs` — 生成的 Rust 代码（多处字符串索引错误）
- 函数：`src/ir/codegen/mod.rs` 中的 `gen_expr`、`IndexGet` 处理
- 记忆：`project.md` 中的 FIND_BUG 转正进度和代码生成器缺陷详情