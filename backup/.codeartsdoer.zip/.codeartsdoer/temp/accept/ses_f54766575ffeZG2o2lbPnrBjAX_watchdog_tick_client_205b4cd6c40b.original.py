#!/usr/bin/env python3
"""Watchdog tick client - check task T0."""

import subprocess
import json
import time
import sys

# Start FIST-Mbt MCP server with node
server_cmd = ["node", r"E:\IDEProjects\AI\FIST-Mbt\_build\js\debug\build\cmd\main\main.js"]
work_dir = r"E:\IDEProjects\AI\FIST-Mbt"

proc = subprocess.Popen(
    server_cmd,
    cwd=work_dir,
    stdin=subprocess.PIPE,
    stdout=subprocess.PIPE,
    stderr=subprocess.PIPE,
    text=True,
    encoding="utf-8",
    errors="replace",
    bufsize=1
)

print(f"Server started with PID: {proc.pid}")

# Wait for server to start
time.sleep(3)

# Build the _meta field
meta = {
    "io.modelcontextprotocol/protocolVersion": "2026-07-28",
    "io.modelcontextprotocol/clientCapabilities": {},
    "io.modelcontextprotocol/clientInfo": {
        "name": "lang-zone-watchdog-cron",
        "version": "1.0.0"
    }
}

def send_request(request):
    """Send a JSON-RPC request and return the response."""
    request_json = json.dumps(request)
    
    proc.stdin.write(request_json + "\n")
    proc.stdin.flush()
    
    # Read response
    start_time = time.time()
    response = ""
    while time.time() - start_time < 15:
        line = proc.stdout.readline()
        if not line:
            time.sleep(0.1)
            continue
        response += line.strip()
        try:
            # Try to parse as JSON
            return json.loads(response)
        except:
            continue
    return None

# Step 1: Get task T0 details
print("\n--- Step 1: Get task T0 details ---")
get_request = {
    "jsonrpc": "2.0",
    "id": 1,
    "method": "tools/call",
    "params": {
        "_meta": meta,
        "name": "get",
        "arguments": {
            "task_id": "T0"
        }
    }
}

get_resp = send_request(get_request)
print(f"Response: {json.dumps(get_resp, indent=2) if get_resp else 'No response'}")

# Step 2: Call watchdog_tick
print("\n--- Step 2: Call watchdog_tick ---")

# Get current time
from datetime import datetime, timezone
current_time = datetime.now(timezone.utc).isoformat()

# Read the latest prompt (20260917.01.06.18.md, modified 2026/9/17 1:07:45)
prompt_path = r"E:\IDEProjects\AI\lang-zone\Gen_Prompts\20260917.01.06.18.md"
with open(prompt_path, 'r', encoding='utf-8') as f:
    prompt_content = f.read()

# Extract task description - use the first line after # 任务目标
lines = prompt_content.split('\n')
task_lines = []
in_description = False
for line in lines:
    if line.startswith('## 任务目标'):
        in_description = True
        continue
    if line.startswith('## 背景'):
        break
    if in_description and line.strip() and not line.startswith('#'):
        task_lines.append(line.strip())

next_description = " ".join(task_lines) if task_lines else "修复 find_bug_libs 测试中失败的两个库（lib_string、lib_json），完成 FIND_BUG 库转正（12/12）"

watchdog_request = {
    "jsonrpc": "2.0",
    "id": 2,
    "method": "tools/call",
    "params": {
        "_meta": meta,
        "name": "watchdog_tick",
        "arguments": {
            "now": current_time,
            "timeout_sec": 2400,
            "namespace": "cron-auto",
            "next_created_by": "watchdog",
            "next_description": next_description,
            "meta_prompt_path": "E:/IDEProjects/AI/lang-zone/Gen_Prompts"
        }
    }
}

watchdog_resp = send_request(watchdog_request)
print(f"Response: {json.dumps(watchdog_resp, indent=2) if watchdog_resp else 'No response'}")

# Cleanup
print("\nCleaning up...")
proc.stdin.close()
proc.terminate()
proc.wait()

print("Done")
