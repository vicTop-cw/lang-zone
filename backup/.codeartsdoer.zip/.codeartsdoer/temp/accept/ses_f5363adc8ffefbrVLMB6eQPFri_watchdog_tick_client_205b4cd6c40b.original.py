#!/usr/bin/env python3
"""Watchdog tick client - dag_publish task"""

import subprocess
import json
import time

server_cmd = ["node", r"E:\IDEProjects\AI\FIST-Mbt\_build\js\debug\build\cmd\main\main.js"]
work_dir = r"E:\IDEProjects\AI\FIST-Mbt"

proc = subprocess.Popen(
    server_cmd,
    cwd=work_dir,
    stdin=subprocess.PIPE,
    stdout=subprocess.PIPE,
    stderr=subprocess.PIPE,
    text=True,
    encoding="utf-8",
    errors="replace",
    bufsize=1
)

print(f"Server started with PID: {proc.pid}")
time.sleep(3)

meta = {
    "io.modelcontextprotocol/protocolVersion": "2026-07-28",
    "io.modelcontextprotocol/clientCapabilities": {},
    "io.modelcontextprotocol/clientInfo": {
        "name": "lang-zone-watchdog-cron",
        "version": "1.0.0"
    }
}

def send_request(request):
    request_json = json.dumps(request)
    proc.stdin.write(request_json + "\n")
    proc.stdin.flush()
    start_time = time.time()
    response = ""
    while time.time() - start_time < 15:
        line = proc.stdout.readline()
        if not line:
            time.sleep(0.1)
            continue
        response += line.strip()
        try:
            return json.loads(response)
        except:
            continue
    return None

# Step 1: Open cron-auto namespace
print("\n--- Step 1: store_open cron-auto ---")
open_request = {
    "jsonrpc": "2.0",
    "id": 1,
    "method": "tools/call",
    "params": {
        "_meta": meta,
        "name": "store_open",
        "arguments": {
            "namespace": "cron-auto"
        }
    }
}
open_resp = send_request(open_request)
print(f"Response: {json.dumps(open_resp, indent=2, ensure_ascii=False) if open_resp else 'No response'}")

# Step 2: dag_publish a task
print("\n--- Step 2: dag_publish task ---")

dag_publish_request = {
    "jsonrpc": "2.0",
    "id": 2,
    "method": "tools/call",
    "params": {
        "_meta": meta,
        "name": "dag_publish",
        "arguments": {
            "project_dir": "E:/IDEProjects/AI/lang-zone",
            "description": "修复 lib_string 回归 + 清理编译警告：修复 lib_string 测试 panic 并清理 3 个编译警告，恢复 FIND_BUG 转正进度至 12/12",
            "namespace": "cron-auto",
            "created_by": "watchdog"
        }
    }
}

dag_publish_resp = send_request(dag_publish_request)
print(f"Response: {json.dumps(dag_publish_resp, indent=2, ensure_ascii=False) if dag_publish_resp else 'No response'}")

# Step 3: List tasks in cron-auto
print("\n--- Step 3: list tasks in cron-auto ---")
list_request = {
    "jsonrpc": "2.0",
    "id": 3,
    "method": "tools/call",
    "params": {
        "_meta": meta,
        "name": "list",
        "arguments": {}
    }
}
list_resp = send_request(list_request)
print(f"Response: {json.dumps(list_resp, indent=2, ensure_ascii=False) if list_resp else 'No response'}")

# Cleanup
print("\nCleaning up...")
proc.stdin.close()
proc.terminate()
proc.wait()

print("Done")
