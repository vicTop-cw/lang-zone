# 任务提示词：修复 lib_hashmap 类型不匹配回归

## 任务目标

修复 find_bug_libs 测试中 lib_hashmap 的类型不匹配错误（`__cs[__i].to_string()` 生成 String 而非 i64），恢复该库的转正状态。

## 背景

**当前状态**：
- 单元测试：420 passed
- find_bug_libs：9 passed, 1 failed, 2 ignored
- 失败测试：lib_hashmap（类型不匹配错误）
- FIND_BUG 转正进度：10/12 已转正，1 个因类型错误回归

**错误信息**：
```
error[E0308]: mismatched types
   --> E:\IDEProjects\AI\lang-zone\FIND_BUG/lib_hashmap\hashmap.rs:180:149
    |
180 | ...size) as usize); if __i >= __cs.len() { '\0'.to_string() } else { __cs[__i].to_string() }});
    |                                            ^^^^^^^^^^^^^^^^ expected `i64`, found `String`
```

**根因分析**：
- `hashmap.rs:180` 中 `__cs[__i].to_string()` 生成了 `String` 类型
- 但上下文期望 `i64` 类型
- 问题出在字符索引访问的代码生成逻辑

**相关文件**：
- `FIND_BUG/lib_hashmap/hashmap.rs:180` - 生成的 Rust 代码（错误位置）
- `FIND_BUG/lib_hashmap/hashmap.lz` - LZ 源码
- `src/ir/codegen/mod.rs` - IR 代码生成器（`gen_index_get` 或相关函数）
- `src/ir/builder.rs` - IR 构建器

## 具体要求

### 1. 定位问题代码

1. 查看生成的 Rust 代码定位错误：
   ```bash
   cat FIND_BUG/lib_hashmap/hashmap.rs | grep -n "__cs\[__i\]"
   ```

2. 查看对应的 LZ 源码：
   ```bash
   cat FIND_BUG/lib_hashmap/hashmap.lz
   ```

3. 手动编译 LZ 源码检查 IR 结构：
   ```bash
   cargo run -- FIND_BUG/lib_hashmap/hashmap.lz --ir-codegen
   ```

### 2. 分析代码生成逻辑

在 `src/ir/codegen/mod.rs` 中搜索：
- `gen_index_get` - 索引访问生成函数
- `IndexGet` - IR 表达式类型
- 字符索引相关的类型处理逻辑

**关键问题**：
- 当索引访问返回 `char` 类型时，代码生成器错误地调用了 `.to_string()`
- 应该正确处理 `char` → `i64` 的类型转换（字符的 ASCII 码值）

### 3. 修复代码生成器

修复 `src/ir/codegen/mod.rs` 中的索引访问生成逻辑：
- 检查 `gen_index_get` 或相关函数
- 确保 `char` 类型的索引访问生成正确的代码
- 对于 `char` 转 `i64`，应生成 `char as i64` 而非 `.to_string()`

### 4. 验证修复

1. 运行 lib_hashmap 测试确认通过：
   ```bash
   cargo test --test find_bug_libs lib_hashmap -- --nocapture
   ```

2. 运行完整 find_bug_libs 测试：
   ```bash
   cargo test --test find_bug_libs
   ```
   - 预期：10 passed, 0 failed, 2 ignored

3. 运行完整测试套件确保无回归：
   ```bash
   cargo test
   ```

## 约束

- 不要修改 `FIND_BUG/lib_hashmap/hashmap.lz`（仅允许调整代码生成器）
- 不要修改 `tests/find_bug_libs.rs` 的测试逻辑
- 确保修复不影响其他已转正库（特别是 lib_string、lib_vector 等）

## 完成标准

- [x] lib_hashmap 测试通过（无类型不匹配错误）
- [x] find_bug_libs 测试结果：10 passed, 0 failed, 2 ignored
- [x] 单元测试 420 passed
- [ ] 提交修复代码，commit message 格式：`fix: 修复 lib_hashmap 字符索引类型不匹配`

## 参考

- 文件：`FIND_BUG/lib_hashmap/hashmap.rs:180` - 错误位置
- 文件：`FIND_BUG/lib_hashmap/hashmap.lz` - LZ 源码
- 函数：`src/ir/codegen/mod.rs` 中的 `gen_index_get` 或相关函数
- 记忆：`project.md` 中的测试状态和 FIND_BUG 转正进度
- 历史：`struct-constructor-infinite-recursion.md` 之前的 bug 修复记录