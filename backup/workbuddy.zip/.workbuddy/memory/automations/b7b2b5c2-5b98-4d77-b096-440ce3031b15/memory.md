# 夜间循环自动化执行记忆（lang-zone / lz）

## 2026-09-27 00:05–01:45 · run_id `2026-09-26-night` · R1-寻虫（1/12）

- 时间门卫：通过（00:05，h<8 → 窗口内，窗口日取昨天）。
- 冷启动：建 `.fist-night/`，FIST-Mbt 走 **Node 直驱 STDIO**（会话内无 `mcp__fist_mbt__*`），
  驱动脚本 `.fist-night/_mcp_call.js`，cwd=`.fist-night`（db 落此处，不污染项目根）。
- 门禁基线实测：`cargo test --no-fail-fast` → 676 passed / 4 failed / 680 total（非引述，本轮实跑）。
- 确诊 3 单并 `report_bug` 入账：哨兵 `\u{1}PATH\u{1}` 在 Call 发射点未剥离（critical）、
  std 模块链拦截被哨兵绕过（high）、compose 闭包参数缺标注 E0282（medium）。
- 产出：`.fist-night/memory/bugs.md`、`.fist-night/memory/reviews/20260927.00.20.00.md`、
  `.fist-night/patches/BUG-N1_call_path_sentinel.patch`（`git apply --check` 通过，未应用）、
  `.fist-night/night_progress.md`。
- 根任务 T0 已归档；8 个叶子走完 omega spec→review→result_verify→verify。
- **挂账待人工**：3 单实际修复（落点全在遗留集 `src/ir/codegen/mod.rs`，零触碰）；
  `report_bug` 重跑导致 BUG-4/5/6 与 BUG-1/2/3 重复，清理需 delete（不可逆黑名单）；
  父层 T0.1~T0.4 卡「待验收+无交付物」（父层 omega 门禁死锁，T0 已在根层归档闭合）。

### 下次接力必须知道的口径
1. **窗口日**：h<8 取昨天；ns 标记 `lz-night-<窗口日>`（server ns 恒 `default`）。
2. **角色名**：`omega_spec_create.author=human_steward`；`omega_spec_review/omega_result_verify.reviewer=verifier`；
   `archive.by=human_steward`；`verify.verifier=human_steward`。其它名字报「未知角色」。
3. **父任务上卷顺序**：叶 → `omega_spec_create` → `omega_spec_review(approve)` → `execute` →
   `omega_result_verify(pass)` → `submit` → `verify`；父任务同样需 `execute`（有 deliverable）才能 result_verify，
   否则卡在「待验收+无交付物」。根任务 T0 未开 omega（`omega_result_verify` 报「未开启」）→ 直接 execute→submit→verify→archive。
4. **report_bug 落点**：`project_dir="."` → `.fist-night/memory/bugs.md`。**只跑一次**，重跑会重复入账。
5. **10x 坑**：`task_plan_deep` 不接受 `omega_strong_verify`/`laya_auto`；`laya` 返回 null（降级留痕）。
6. 本轮时间盒 100 分钟只够 1 个环节（cargo test 全量约 12 分钟 + MCP 链路调试）。下轮优先「R1-修复」。

## 2026-09-27 03:02–03:55 · run_id `2026-09-26-night` · R1-修复（2/12）

- 时间门卫通过（03:02，h<8 → 窗口日取昨天）；账本 run_id 一致，接力 R1-修复。
- 核心手法：**隔离副本验证**——遗留集零触碰红线与「必须实跑验证」冲突时，把整个工作树
  tar 到仓库外目录改+跑+出补丁，仓库零改动。本轮首次打通，下轮直接复用。
- 战果：BUG-N1/N2 已验证修复（含 N2 次级缺陷：方法段也带哨兵），BUG-N3 备妥经实跑验证的语料级补丁后挂账。
  隔离副本门禁 679/1/680（基线 676/4/680），golden 无漂移。root T0r8 + 4 父 + 8 叶全部 已完成/已归档。
- 新口径（下次接力必读）：
  1. 副本须先 `cargo build -p lz_builtins --lib`，否则 41 例误报 rlib not found；
  2. 父层死锁解锁 = `reject(reviewer=verifier) → retry → execute → omega_result_verify → submit → verify`；
  3. 补丁用 `git diff --no-index a/<p> b/<p>` 生成后需 sed 修三层 `a/a/` `b/b/` 头；
  4. `report_bug` 不要重跑（会重复入账），新缺陷并入同源单不重复计账；
  5. 隔离副本路径 `E:\IDEProjects\AI\_lz_night_scratch\lang-zone`（可复用，仓库外不污染）。
- 下轮 next：**R1-验证**（3/12）。

## 2026-09-27 05:54–07:3x · run_id `2026-09-26-night` · R1-验证（3/12）

- 时间门卫通过（05:54，h<8 → 窗口日取昨天）；账本 run_id 一致，接力 R1-验证。本次**只完成 1 个环节**
  （100 分钟时间盒耗尽），next = **R1-打磨（4/12）**。
- 核心战果：隔离副本门禁 **680 passed / 0 failed / 680 total**（26 target 全绿，较上轮 679/1 再收敛 1 例，
  N3 语料补丁生效）；golden 零漂移；`output_validate` = pass 6/6 / l4-pass。根任务 T0r12 已归档，5 父 + 10 叶全绿。
- 新发现：DEMO 全量闸门（`--ignored`，非门禁）2 项新增失败 `list.lz` / `set.lz`（E0614）。
  **用「反向对照实验」归因**：副本回退本夜补丁后重跑，结果同样 326/307/19 且同样 E0614 → 非本夜引入。
  已入账 BUG-7 / BUG-N4（high，任务 T0r10）。
- 欠账补链：T0.1~T0.4 全部转 已完成（4/4）；T0r2~T0r7 重复单清理需 delete → 挂账待人工。
- 新口径（**修正了上轮的错误记录**）：
  1. `task_plan_deep` **接受** `omega_strong_verify` / `laya_auto`；只有传 `omega_strong_verify:true`
     子任务 description 才会带 `[omega:required]`（写在 laws 文本里不传播）。
  2. `output_validate.artifacts` 必须是对象数组 `[{"path":"..."}]`。
  3. `_mcp_call.js` 批量最后一条偶发返回上一条响应 → 终态以 `omega_status` 复查为准。
  4. 反向对照实验 = 归因「是否本夜引入」的合规手法，下轮复用。
- 产出：`.fist-night/memory/reviews/20260927.07.21.00.md`、三个实跑日志；账本已追加 R1-验证 与口径修正。
